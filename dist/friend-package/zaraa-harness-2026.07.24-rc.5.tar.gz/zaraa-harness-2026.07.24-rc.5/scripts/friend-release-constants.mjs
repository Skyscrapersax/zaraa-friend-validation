/**
 * Shared paths and friend-release rules.
 * Staging skip basenames align with friend-bundle-audit forbidden basenames where they overlap.
 */

export const FRIEND_PACKAGE_ROOT_REL = "dist/friend-package";
export const FRIEND_PACKAGE_LATEST_REL = `${FRIEND_PACKAGE_ROOT_REL}/latest.json`;
export const FRIEND_RELEASE_MANIFEST_REL = "dist/release/zaraa-friend-release-manifest.json";

/** Workspace trees required by staged runtime manifests. */
export const FRIEND_PACKAGE_STAGED_DIRECTORIES = [
	"packages/core",
	"packages/web",
	"packages/cli",
	"packages/gui",
	"packages/shared",
	"packages/sandbox",
	"packages/deerflow-compat",
	"packages/predict",
	"packages/trading-kernel",
	"plugins",
];

export const FRIEND_TRADING_SECRET_KEYS = [
	"apiKey",
	"apiSecret",
	"solanaDexSecretKey",
	"liveModeLock",
];
export const FRIEND_POLYMARKET_SECRET_KEYS = ["apiKey", "apiSecret", "apiPassphrase", "privateKey"];

export function missingFriendPackageLatestMessage(relPath = FRIEND_PACKAGE_LATEST_REL) {
	return `${relPath} is missing. Generate it with \`pnpm ship:manifest\` then \`pnpm ship:package\`. Use \`pnpm ship:candidate\` to build and verify a fresh validation candidate.`;
}

/** Basenames skipped when staging friend package trees (friend-package.mjs). */
export const FRIEND_PACKAGE_STAGING_SKIP_BASENAMES = new Set([
	".DS_Store",
	".git",
	".npmrc",
	".turbo",
	".vite",
	".zaraa",
	":memory:",
	"__fixtures__",
	"coverage",
	"fixtures",
	"install-output.log",
	"node_modules",
	"target",
]);

export function friendPackageStagingShouldSkip(name) {
	if (name === ".env" || name.startsWith(".env.")) {
		return true;
	}
	// SQLite URI filenames are leaked local state; host-built native addons can
	// embed owner source paths and are optional because shipped wrappers fall back.
	if (name.startsWith("file:") || name.endsWith(".node")) {
		return true;
	}
	// Never ship live or pre-mutation home-config snapshots into a friend kit.
	if (
		name === "zaraa.config.json" ||
		name.includes("pre-friend-pin") ||
		name.includes("pre-setup-wizard")
	) {
		return true;
	}
	if (name === "__tests__" || name === "__snapshots__") {
		return true;
	}
	if (/\.(?:test|spec)\.[cm]?[jt]sx?$/i.test(name)) {
		return true;
	}
	if (
		/\.(?:jsonl|key|log(?:\.\d+)?|ndjson|p12|pem|pfx|(?:db|sqlite|sqlite3)(?:-(?:journal|shm|wal))?)$/i.test(
			name,
		)
	) {
		return true;
	}
	if (
		/^(?:ab-.+\.json|(?:bench-.+-results|pack-\d+-(?:progress|results(?:-[^.]+)?)|task-test-(?:progress|results))\.json|pack-\d+-scorecard\.md|.+-ids\.json)$/i.test(
			name,
		)
	) {
		return true;
	}
	if (
		/^(?:g400|grow421|optimize-rounds|sip450-smoke|iter50-.+|nemotron-ultra-.+|qwen35-r.+)$/i.test(
			name,
		)
	) {
		return true;
	}
	// Volatile test scratch dirs (e.g. tmp-zara-policy-XXXXXX) are created and
	// deleted by concurrently running suites; walking them races the deleter and
	// can hang the copy, and they must never ship in a friend package.
	if (name.startsWith("tmp-zara-")) {
		return true;
	}
	return FRIEND_PACKAGE_STAGING_SKIP_BASENAMES.has(name);
}

/**
 * Path-aware staging skip for friend kits.
 * relativeDir is the directory containing name, relative to the package/source root
 * (posix separators, no leading ./ , no trailing slash). Example: name=src,
 * relativeDir=packages/core → skip (friend runtime ships packages pkg dist only).
 * Plugins keep their src trees (plugins/... is not under packages/pkg).
 */
export function friendPackageStagingShouldSkipEntry(name, relativeDir = "") {
	if (friendPackageStagingShouldSkip(name)) {
		return true;
	}
	const rel = String(relativeDir || "")
		.replaceAll("\\", "/")
		.replace(/^\.\/?/, "")
		.replace(/\/$/, "");
	// packages/<pkg>/src is not a friend runtime surface.
	if (name === "src" && /^packages\/[^/]+$/.test(rel)) {
		return true;
	}
	return false;
}

/**
 * Forbidden bundle/archive path basenames (friend-bundle-audit.mjs).
 * Keep overlapping entries identical to friendPackageStagingShouldSkip.
 */
export const FRIEND_BUNDLE_FORBIDDEN_BASENAMES = new Set([
	...FRIEND_PACKAGE_STAGING_SKIP_BASENAMES,
	".env",
	".env.local",
	".env.production",
	".env.development",
	"npm-cache",
	"pnpm-store",
	"zaraa.config.json",
]);

export const FRIEND_BUNDLE_FORBIDDEN_PATH_REGEXES = [
	/(^|\/)file:[^/]*(\/|$)/i,
	/(^|\/)[^/]+\.node$/i,
	/(^|\/)tmp-zara-[^/]*(\/|$)/,
	/(^|\/)(:memory:|__fixtures__|__tests__|__snapshots__|fixtures)(\/|$)/,
	// Friend kits must not ship monorepo package source trees (dist-only runtime).
	/(^|\/)packages\/[^/]+\/src(\/|$)/,
	/(^|\/)[^/]+\.(?:test|spec)\.[cm]?[jt]sx?$/i,
	/(^|\/)[^/]+\.(?:jsonl|key|log(?:\.\d+)?|ndjson|p12|pem|pfx|(?:db|sqlite|sqlite3)(?:-(?:journal|shm|wal))?)$/i,
	/(^|\/)(?:ab-.+\.json|(?:bench-.+-results|pack-\d+-(?:progress|results(?:-[^.]+)?)|task-test-(?:progress|results))\.json|pack-\d+-scorecard\.md|[^/]+-ids\.json)$/i,
	/(^|\/)(?:g400|grow421|optimize-rounds|sip450-smoke|iter50-[^/]+|nemotron-ultra-[^/]+|qwen35-r[^/]+)(\/|$)/i,
	/(^|\/)\.zaraa(\/|$)/,
	/(^|\/)node_modules(\/|$)/,
	/(^|\/)\.git(\/|$)/,
	/(^|\/)(\.bash_history|\.zsh_history|\.ssh|cookies|local storage)(\/|$)/i,
	/(^|\/)(install-output\.log|zaraa\.config\.json|\.npmrc|\.env(?:\.[^/]*)?)(\/|$)/i,
	// Pre-mutation config backups contain live credentials; never ship them.
	/(^|\/)[^/]*pre-friend-pin[^/]*(\/|$)/i,
	/(^|\/)[^/]*pre-setup-wizard[^/]*(\/|$)/i,
];
