# Zaraa Friend Package Known Issues

## Current known issues

- macOS clean-folder install validation is pending.
- Windows installer validation is pending.
- Linux installer validation is pending.
- Native signed installers are not ready yet; this is still a source-based friend harness.
- Friends should not reuse Zaraa's local gateway key or config.

## Reporting format

Ask friends for:

1. Operating system and version.
2. Which installer they ran.
3. The visible error text.
4. Whether the dashboard URL opened.
5. Whether Ship Readiness loaded and scrolled.

Do not ask for:

1. Gateway API keys.
2. Local config files.
3. Full logs with secrets.
4. Private workspace files.
5. `~/.zaraa`.
