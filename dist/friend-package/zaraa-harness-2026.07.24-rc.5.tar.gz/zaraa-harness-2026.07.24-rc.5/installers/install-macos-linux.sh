#!/usr/bin/env bash
set -euo pipefail

KIT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ZARAA_DIR="${ZARAA_DIR:-$HOME/zaraa}"
CONFIG_DIR="$HOME/.zaraa"
CONFIG_FILE="$CONFIG_DIR/zaraa.config.json"
NODE_MIN_VERSION=22

ok() { echo "  [OK]  $1"; }
warn() { echo "  [!!]  $1"; }
fail() { echo "  [ERR] $1"; exit 1; }
step() { echo ""; echo "-- $1 --"; }

echo ""
echo "  Zaraa Friend Harness Installer"
echo "  Package: zaraa-harness-2026.07.24-rc.5"
echo ""

step "Checking Node.js"
if ! command -v node >/dev/null 2>&1; then
	fail "Node.js 22+ is required. Install it from https://nodejs.org/ and rerun this installer."
fi

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
if [ "$NODE_MAJOR" -lt "$NODE_MIN_VERSION" ]; then
	fail "Node.js 22+ is required, found $(node -v)."
fi
ok "Node.js $(node -v)"

step "Preparing install directory"
mkdir -p "$ZARAA_DIR"
ok "Install target ready at $ZARAA_DIR"

step "Preparing local gateway key"
# Fail-closed path control BEFORE minting a gateway key: never write secrets through
# a symlink config dir/file (would land the key outside the operator-intended home).
if [ -L "$CONFIG_DIR" ]; then
	fail "Refusing install: config directory is a symlink ($CONFIG_DIR). Replace it with a real directory under $HOME/.zaraa."
fi
if [ -L "$CONFIG_FILE" ]; then
	fail "Refusing install: config file is a symlink ($CONFIG_FILE). Replace it with a regular file under $HOME/.zaraa."
fi
if [ -e "$CONFIG_FILE" ] && [ ! -f "$CONFIG_FILE" ]; then
	fail "Refusing install: config path is not a regular file ($CONFIG_FILE)."
fi
# Mode 0700 so other local users cannot list pre-pin backup basenames beside the config.
mkdir -p "$CONFIG_DIR"
# Re-check after mkdir: mkdir -p follows an existing symlink parent rather than replacing it.
if [ -L "$CONFIG_DIR" ]; then
	fail "Refusing install: config directory is a symlink after mkdir ($CONFIG_DIR)."
fi
chmod 700 "$CONFIG_DIR" 2>/dev/null || true
if [ ! -f "$CONFIG_FILE" ]; then
	if [ -L "$CONFIG_FILE" ]; then
		fail "Refusing install: config file is a symlink ($CONFIG_FILE)."
	fi
	ZARAA_KEY="$(node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))")"
	# umask 077 so the gateway key never lands world-readable before chmod.
	( umask 077; cat > "$CONFIG_FILE" <<JSON
{
  "gateway": {
    "trusted": false,
    "auth": {
      "apiKey": "$ZARAA_KEY"
    }
  },
  "performance": "minimal",
  "autonomy": {
    "mode": "off",
    "creativeJoy": {
      "enabled": false
    }
  },
  "scheduler": {
    "tasks": [
      {
        "id": "daily-crypto-discipline",
        "enabled": false,
        "schedule": "daily 09:00 UTC",
        "zone": "guarded",
        "prompt": "Daily trading discipline snapshot.",
        "notify": "none",
        "silent": true
      }
    ],
    "overnight": {
      "enabled": false
    }
  },
  "trading": {
    "backgroundAutomation": false,
    "paperMode": true,
    "autoExecuteLive": false
  },
  "predictions": {
    "paperMode": true,
    "autoExecuteLive": false
  },
  "calendar": {
    "enabled": false
  },
  "messaging": {
    "imessage": {
      "enabled": false
    }
  },
  "voice": {
    "provider": "pipeline",
    "enabled": false,
    "facetime": {
      "enabled": false
    }
  }
}
JSON
)
	chmod 600 "$CONFIG_FILE" 2>/dev/null || true
	ok "Created local gateway config at $CONFIG_FILE"
else
	ok "Keeping existing local gateway config"
fi

# Always re-pin paper-only money rails (preserves gateway key; forces paperMode true).
step "Pinning friend paper-only trading rails"
node "$KIT_DIR/scripts/friend-config-safety.mjs" --config "$CONFIG_FILE"

step "Setting up package manager"
if command -v corepack >/dev/null 2>&1; then
	corepack enable >/dev/null 2>&1 || true
	corepack prepare pnpm@9.15.4 --activate >/dev/null 2>&1 || true
fi

if ! command -v pnpm >/dev/null 2>&1; then
	fail "pnpm is required. Run: corepack enable && corepack prepare pnpm@9.15.4 --activate"
fi

ok "pnpm $(pnpm -v)"

step "Installing or updating Zaraa"
node "$KIT_DIR/scripts/friend-kit-update.mjs" --source "$KIT_DIR" --target "$ZARAA_DIR"

echo ""
echo "Install complete."
echo "1. Connect a model provider:"
echo "  cd $ZARAA_DIR && pnpm setup"
echo ""
echo "2. Verify setup:"
echo "  cd $ZARAA_DIR && pnpm doctor"
echo ""
echo "3. Start Zaraa:"
echo "  cd $ZARAA_DIR && pnpm start"
echo ""
echo "4. Open:"
echo "  http://localhost:3927/"
