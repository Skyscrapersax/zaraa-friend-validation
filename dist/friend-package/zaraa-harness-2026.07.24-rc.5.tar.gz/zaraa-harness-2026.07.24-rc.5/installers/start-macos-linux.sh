#!/usr/bin/env bash
set -euo pipefail

ZARAA_DIR="${ZARAA_DIR:-$HOME/zaraa}"

if [ ! -d "$ZARAA_DIR" ]; then
	echo "Zaraa is not installed at $ZARAA_DIR yet."
	echo "Run ./installers/install-macos-linux.sh first."
	exit 1
fi

cd "$ZARAA_DIR"
echo "Starting Zaraa from $ZARAA_DIR"
echo "Open http://localhost:3927/ after the gateway is ready."
pnpm start
