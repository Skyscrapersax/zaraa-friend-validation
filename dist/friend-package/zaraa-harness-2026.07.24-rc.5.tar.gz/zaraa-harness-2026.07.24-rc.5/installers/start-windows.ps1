param(
  [string]$ZaraaDir = "$env:USERPROFILE\zaraa"
)

$ErrorActionPreference = "Stop"

if (!(Test-Path $ZaraaDir)) {
  Write-Host "Zaraa is not installed at $ZaraaDir yet."
  Write-Host "Run .\installers\install-windows.ps1 first."
  exit 1
}

Set-Location $ZaraaDir
Write-Host "Starting Zaraa from $ZaraaDir"
Write-Host "Open http://localhost:3927/ after the gateway is ready."
pnpm start
if ($LASTEXITCODE -ne 0) {
  Write-Host "  [ERR] pnpm start failed (exit $LASTEXITCODE)."
  exit $LASTEXITCODE
}
